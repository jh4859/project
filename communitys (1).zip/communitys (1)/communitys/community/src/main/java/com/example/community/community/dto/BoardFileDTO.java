package com.example.community.community.dto;

import com.example.community.community.entity.BoardFileEntity;
import lombok.Getter;

@Getter
public class BoardFileDTO {
    private Long id;
    private String originalName;
    private String savedName;
    private String downloadUrl;

    public BoardFileDTO(BoardFileEntity entity) {
        this.id = entity.getId();
        this.originalName = entity.getOriginalName();
        this.savedName = entity.getSavedName();
        // 파일의 다운로드 경로를 만들어서 URL을 설정
        this.downloadUrl = "/api/board/download/" + entity.getSavedName();
    }

    // 🔧 요거 추가
    public BoardFileDTO(String originalName, String savedName, String downloadUrl) {
        this.originalName = originalName;
        this.savedName = savedName;
        this.downloadUrl = downloadUrl;
    }
}