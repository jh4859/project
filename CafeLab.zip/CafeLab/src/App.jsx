import React from 'react';
import { BrowserRouter as Router, Routes, Route } from 'react-router-dom';
import "./App.css"
import './css/Nav.css'
import './css/Tabs.css'
import './css/Board.css'
import './css/CommunityPage.css'

import Nav from './components/Nav';
import CommunityPage from './components/CommunityPage'

function App() {
  return (
    <>
      <Router>
        <div className="container">
        <Nav />
        <CommunityPage />  
          <Routes>
            
          </Routes>
        </div>
      </Router>
    </>
  );
}

export default App;