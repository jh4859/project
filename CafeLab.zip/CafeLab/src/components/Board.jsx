import { useState, useContext } from "react";

function Board() {

  return(
    <>
        <div className="main-section">
            <div className="search-box-section">
                <div className="search-box">
                    <form action="search">
                        <input type="search" placeholder="검색어를 입력해주세요."/>
                        <button>검색</button>
                    </form>
                </div>
            </div>
            
            <div className="tbl-container">
                <table>
                    <thead>
                        <tr>
                            <th>번호</th>
                            <th>제목</th>
                            <th>작성자</th>
                            <th>작성일</th>
                            <th>조회수</th>
                        </tr>
                    </thead>
                    <tbody>
                        <tr>
                            <td>10</td>
                            <td><a href="#"><strong>공지사항입니다. 확인해 주세요.</strong></a></td>
                            <td>관리자</td>
                            <td>2025.03.18</td>
                            <td>10</td>
                        </tr>
                        <tr>
                            <td>9</td>
                            <td><a href="#"><strong>공지사항입니다. 확인해 주세요.</strong></a></td>
                            <td>관리자</td>
                            <td>2025.03.18</td>
                            <td>10</td>
                        </tr>
                        <tr>
                            <td>8</td>
                            <td><a href="#"><strong>공지사항입니다. 확인해 주세요.</strong></a></td>
                            <td>관리자</td>
                            <td>2025.03.18</td>
                            <td>10</td>
                        </tr>
                        <tr>
                            <td>7</td>
                            <td><a href="#"><strong>공지사항입니다. 확인해 주세요.</strong></a></td>
                            <td>관리자</td>
                            <td>2025.03.18</td>
                            <td>10</td>
                        </tr>
                        <tr>
                            <td>6</td>
                            <td><a href="#"><strong>공지사항입니다. 확인해 주세요.</strong></a></td>
                            <td>관리자</td>
                            <td>2025.03.18</td>
                            <td>10</td>
                        </tr>
                        <tr>
                            <td>5</td>
                            <td><a href="#"><strong>공지사항입니다. 확인해 주세요.</strong></a></td>
                            <td>관리자</td>
                            <td>2025.03.18</td>
                            <td>10</td>
                        </tr>
                        <tr>
                            <td>4</td>
                            <td><a href="#"><strong>공지사항입니다. 확인해 주세요.</strong></a></td>
                            <td>관리자</td>
                            <td>2025.03.18</td>
                            <td>10</td>
                        </tr>
                        <tr>
                            <td>3</td>
                            <td><a href="#"><strong>공지사항입니다. 확인해 주세요.</strong></a></td>
                            <td>관리자</td>
                            <td>2025.03.18</td>
                            <td>10</td>
                        </tr>
                        <tr>
                            <td>2</td>
                            <td><a href="#"><strong>공지사항입니다. 확인해 주세요.</strong></a></td>
                            <td>관리자</td>
                            <td>2025.03.18</td>
                            <td>10</td>
                        </tr>
                        <tr>
                            <td>1</td>
                            <td><a href="#"><strong>공지사항입니다. 확인해 주세요.</strong></a></td>
                            <td>관리자</td>
                            <td>2025.03.18</td>
                            <td>10</td>
                        </tr>
                    </tbody>
                </table>    
            </div>

            <div className="main-bottom">
                <div className="add-button">
                    <button>글쓰기</button>
                </div>
                <div className="page">
                    <a href="#">1</a>
                    <a href="#">2</a>
                    <a href="#">3</a> 
                </div>
            </div>
        </div> 
    </>
  );
}



export default Board