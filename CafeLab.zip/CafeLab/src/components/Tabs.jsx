import React, { useState } from 'react';
import { Link } from 'react-router-dom';
import Board from './Board';

const Tabs = () => {
  const [activeTab, setActiveTab] = useState('tab1');

  const handleTabClick = (tabId) => {
    setActiveTab(tabId);
  };

  return (
    <div className="main-section">
      <div className="tab-button">
        <ul className="tabs">
          <li
            className={`tab_item ${activeTab === 'tab1' ? 'active' : ''}`}
            onClick={() => handleTabClick('tab1')}
          >
            <Link to="#tab1">공지사항</Link>
          </li>
          <li
            className={`tab_item ${activeTab === 'tab2' ? 'active' : ''}`}
            onClick={() => handleTabClick('tab2')}
          >
            <Link to="#tab2">소통창</Link>
          </li>
          <li
            className={`tab_item ${activeTab === 'tab3' ? 'active' : ''}`}
            onClick={() => handleTabClick('tab3')}
          >
            <Link to="#tab3">FAQ</Link>
          </li>
        </ul>
      </div>

      <div className="tab-content">
        {activeTab === 'tab1' && <div>{Board}</div>}
        {activeTab === 'tab2' && <div>소통창 내용...</div>}
        {activeTab === 'tab3' && <div>FAQ 내용...</div>}
      </div>
    </div>
  );
};

export default Tabs;
