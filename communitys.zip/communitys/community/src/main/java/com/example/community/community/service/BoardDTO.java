package com.example.community.community.service;

import lombok.Data;
import lombok.Getter;
import lombok.Setter;

import java.time.LocalDateTime;
import java.util.List;

@Data
@Getter
@Setter
public class BoardDTO {
    private Long id;
    private String title;
    private String content;
    private String category;
    private LocalDateTime createDate;
    private List<BoardFileDTO> files; // 첨부파일 DTO 리스트

    public Long getId() {
        return id;
    }

    public void setId(Long id) {
        this.id = id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getContent() {
        return content;
    }

    public void setContent(String content) {
        this.content = content;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public LocalDateTime getCreateDate() {
        return createDate;
    }

    public void setCreateDate(LocalDateTime createDate) {
        this.createDate = createDate;
    }

    public List<BoardFileDTO> getFiles() {
        return files;
    }

    public void setFiles(List<BoardFileDTO> files) {
        this.files = files;
    }
}
