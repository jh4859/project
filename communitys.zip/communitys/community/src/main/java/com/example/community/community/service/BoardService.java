package com.example.community.community.service;

import com.example.community.community.entity.BoardEntity;
import com.example.community.community.entity.BoardFileEntity;
import com.example.community.community.entity.ComImgEntity;
import com.example.community.repository.BoardFileRepository;
import com.example.community.repository.BoardRepository;
import com.example.community.community.dto.BoardDTO;
import com.example.community.community.dto.BoardFileDTO;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;

@Service
public class BoardService {

    private final BoardRepository boardRepository;
    private final BoardFileRepository boardFileRepository;

    // application.properties에 정의된 업로드 경로를 가져오기 위한 변수
    @Value("${file.upload.dir}")
    private String uploadDir;

    // 생성자 주입
    @Autowired
    public BoardService(BoardRepository boardRepository, BoardFileRepository boardFileRepository) {
        this.boardRepository = boardRepository;
        this.boardFileRepository = boardFileRepository;
    }

    public List<BoardDTO> getAllPosts() {
        return boardRepository.findAll().stream()
                .map(BoardDTO::new)  // BoardDTO 생성자 사용
                .collect(Collectors.toList());
    }

    public BoardDTO convertToDTO(BoardEntity boardEntity) {
        List<BoardFileDTO> fileDTOs = boardEntity.getFiles().stream()
                .map(file -> new BoardFileDTO(
                        file.getOriginalName(),
                        file.getSavedName(),
                        "/api/board/download/" + file.getSavedName(),
                        file.getSize(),
                        file.getPath(), // ✅ 경로 포함
                        file.getFileType()
                ))
                .collect(Collectors.toList());

        BoardDTO dto = new BoardDTO();
        dto.setId(boardEntity.getId());
        dto.setTitle(boardEntity.getTitle());
        dto.setTextContent(boardEntity.getTextContent());
        dto.setCategory(boardEntity.getCategory());
        dto.setCreateDate(boardEntity.getCreatedAt());
        dto.setFiles(fileDTOs);

        return dto;
    }

    // 게시글 저장 서비스
    public void savePost(String category, String title, String textContent, List<String> imageUrls, List<MultipartFile> files, List<MultipartFile> imageFiles) {

        // 1. 게시글 저장
        BoardEntity board = new BoardEntity();
        board.setCategory(category);
        board.setTitle(title);
        board.setTextContent(textContent);

        // 서버의 기본 URL을 가져오는 부분 수정
        String baseUrl = ServletUriComponentsBuilder.fromCurrentContextPath()
                .build()
                .toUriString(); // ex. "http://localhost:8080"

        List<ComImgEntity> imageEntities = new ArrayList<>();
        if (imageFiles != null && !imageFiles.isEmpty()) {
            for (MultipartFile imageFile : imageFiles) {
                String originalFilename = imageFile.getOriginalFilename();
                String fileExtension = originalFilename != null ? originalFilename.substring(originalFilename.lastIndexOf(".")) : ".jpg";
                String savedFilename = UUID.randomUUID().toString() + fileExtension;
                Path path = Paths.get(uploadDir + "/" + savedFilename);

                try {
                    Files.copy(imageFile.getInputStream(), path, StandardCopyOption.REPLACE_EXISTING);

                    ComImgEntity imageEntity = new ComImgEntity();
                    imageEntity.setImgName(originalFilename);
                    imageEntity.setImgSize(imageFile.getSize());
                    imageEntity.setImgType(imageFile.getContentType());

                    // 절대 경로로 URL 변경
                    imageEntity.setImgUrl(baseUrl + "/uploads/" + savedFilename);  // 절대 경로로 수정
                    imageEntity.setBoard(board);

                    imageEntities.add(imageEntity);
                } catch (IOException e) {
                    throw new RuntimeException("이미지 업로드 중 오류 발생", e);
                }
            }
        }

        board.setImages(imageEntities);

        // 파일 처리
        List<BoardFileEntity> fileEntities = new ArrayList<>();
        if (files != null && !files.isEmpty()) {
            for (MultipartFile file : files) {
                String originalFilename = file.getOriginalFilename();
                String fileExtension = originalFilename != null ? originalFilename.substring(originalFilename.lastIndexOf(".")) : ".tmp";
                String savedFilename = UUID.randomUUID().toString() + fileExtension;
                Path path = Paths.get(uploadDir + "/" + savedFilename);

                try {
                    Files.copy(file.getInputStream(), path, StandardCopyOption.REPLACE_EXISTING);

                    // 파일 엔티티 생성
                    BoardFileEntity fileEntity = new BoardFileEntity();
                    fileEntity.setOriginalName(originalFilename);
                    fileEntity.setSavedName(savedFilename);
                    fileEntity.setSize(file.getSize());
                    fileEntity.setPath(path.toString());
                    fileEntity.setFileType(file.getContentType());
                    fileEntity.setBoard(board);  // 해당 파일을 게시글에 연결
                    fileEntities.add(fileEntity);
                } catch (IOException e) {
                    throw new RuntimeException("파일 업로드 중 오류 발생", e);
                }
            }
        }

        // 파일 엔티티 리스트 추가
        board.setFiles(fileEntities);

        boardRepository.save(board);  // 게시글과 파일 모두 저장
    }


    public BoardDTO getPostById(String category, Long id) {
        // 카테고리 별로 조회하거나, 카테고리를 무시할 수도 있음
        BoardEntity post = boardRepository.findById(id)
                .orElseThrow(() -> new RuntimeException("게시글이 존재하지 않습니다."));

        return new BoardDTO(post); // DTO 변환
    }
}
