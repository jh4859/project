package com.example.community.service;

import com.example.community.community.entity.BoardEntity;
import com.example.community.community.entity.BoardFileEntity;
import com.example.community.community.service.BoardDTO;

import com.example.community.community.service.BoardFileDTO;
import com.example.community.repository.BoardFileRepository;
import com.example.community.repository.BoardRepository;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.nio.file.StandardCopyOption;
import java.time.LocalDateTime;
import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;

@Service
public class BoardService {

    private final BoardRepository boardRepository;
    private final BoardFileRepository boardFileRepository;

    // application.properties에 정의된 업로드 경로를 가져오기 위한 변수
    @Value("${file.upload.dir}")
    private String uploadDir;

    // 생성자 주입
    @Autowired
    public BoardService(BoardRepository boardRepository, BoardFileRepository boardFileRepository) {
        this.boardRepository = boardRepository;
        this.boardFileRepository = boardFileRepository;
    }

    public List<BoardEntity> getAllPosts() {
        return boardRepository.findAll();
    }

    public BoardDTO convertToDTO(BoardEntity boardEntity) {
        List<BoardFileDTO> fileDTOs = boardEntity.getFiles().stream()
                .map(file -> new BoardFileDTO(
                        file.getOriginalName(),
                        "/api/board/download/" + file.getSavedName() // 다운로드 경로 구성
                ))
                .collect(Collectors.toList());

        BoardDTO dto = new BoardDTO();
        dto.setId(boardEntity.getId());
        dto.setTitle(boardEntity.getTitle());
        dto.setContent(boardEntity.getContent());
        dto.setCategory(boardEntity.getCategory());
        dto.setCreateDate(boardEntity.getCreateDate().toString());
        dto.setFiles(fileDTOs);

        return dto;
    }

    // 게시글 저장 서비스
    public Long savePost(String title, String content, String category, List<MultipartFile> files) throws IOException {
        // 게시글 객체 생성 및 정보 저장
        BoardEntity board = new BoardEntity();
        board.setTitle(title);
        board.setContent(content);
        board.setCategory(category);
        board.setCreateDate(LocalDateTime.now());

        // 게시글 먼저 저장 (ID 생성됨)
        boardRepository.save(board);

        // 첨부 파일이 있을 경우
        if (files != null && !files.isEmpty()) {
            for (MultipartFile file : files) {
                String originalName = file.getOriginalFilename();

                // UUID로 저장 파일명 생성 (중복 방지)
                String savedName = UUID.randomUUID() + "_" + originalName;

                // 저장 경로 설정
                Path filePath = Paths.get(uploadDir, savedName);

                // 파일 저장 (같은 이름 있을 경우 덮어쓰기)
                Files.copy(file.getInputStream(), filePath, StandardCopyOption.REPLACE_EXISTING);

                // 파일 메타데이터 저장
                BoardFileEntity fileEntity = new BoardFileEntity();
                fileEntity.setOriginalName(originalName);
                fileEntity.setSavedName(savedName);
                fileEntity.setPath(filePath.toString());
                fileEntity.setBoard(board); // 게시글과 연관 관계 설정

                boardFileRepository.save(fileEntity);
            }
        }

        // 저장된 게시글 ID 반환
        return board.getId();
    }
}
