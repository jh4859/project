package com.example.community.community.controller;

import com.example.community.community.service.BoardService;
import com.fasterxml.jackson.core.type.TypeReference;
import com.fasterxml.jackson.databind.ObjectMapper;
import jakarta.servlet.http.HttpServletRequest;
import org.springframework.beans.factory.annotation.Value;
import org.springframework.core.io.FileSystemResource;
import org.springframework.http.HttpStatus;
import org.springframework.http.MediaType;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;
import org.springframework.web.servlet.support.ServletUriComponentsBuilder;

import java.io.File;
import java.io.IOException;
import java.nio.file.Files;
import java.nio.file.Path;
import java.nio.file.Paths;
import java.util.*;

@RestController
@RequestMapping("/api/board")
public class BoardController {

    private final BoardService boardService;

    @Value("${file.upload.dir}")
    private String uploadDir;

    public BoardController(BoardService boardService) {
        this.boardService = boardService;
    }

    // 게시글 등록
    @PostMapping("/{category}")
    public ResponseEntity<?> saveBoard(
            @PathVariable String category,
            @RequestParam("title") String title,
            @RequestParam("textContent") String textContent,
            @RequestParam(value = "imageUrls", required = false) String imageUrlsJson,
            @RequestPart(value = "imageFiles", required = false) List<MultipartFile> imageFiles,
            @RequestPart(value = "files", required = false) List<MultipartFile> files
    ) {
        try {
            List<String> imageUrls = new ArrayList<>();
            if (imageUrlsJson != null && !imageUrlsJson.isEmpty()) {
                imageUrls = new ObjectMapper().readValue(imageUrlsJson, new TypeReference<List<String>>() {});
            }

            boardService.savePost(category, title, textContent, imageUrls, files, imageFiles);
            return ResponseEntity.ok("게시글 등록 완료!");
        } catch (Exception e) {
            e.printStackTrace();
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body("게시글 등록 실패: " + e.getMessage());
        }
    }

    // 이미지 업로드 (CKEditor에서 사용)
    @PostMapping(value = "/image-upload", consumes = MediaType.MULTIPART_FORM_DATA_VALUE)
    public ResponseEntity<?> uploadImage(@RequestParam("upload") MultipartFile file,  HttpServletRequest request) {
        try {
            if (file.isEmpty()) {
                return ResponseEntity.badRequest().body(Map.of("uploaded", false, "error", Map.of("message", "빈 파일입니다.")));
            }

            String originalFilename = file.getOriginalFilename();
            String savedFilename = UUID.randomUUID() + "_" + originalFilename;
            Path savePath = Paths.get(uploadDir, savedFilename);
            Files.createDirectories(savePath.getParent());
            Files.copy(file.getInputStream(), savePath);

            String imageUrl = "/uploads/" + savedFilename;

            // 현재 요청을 기준으로 "http://localhost:8080" 부분을 가져와 준다
            String baseUrl = ServletUriComponentsBuilder.fromRequestUri(request)
                    .replacePath(null)     // path 제거 -> http://localhost:8080
                    .build()
                    .toUriString();

            String fullUrl = baseUrl + imageUrl;

            // ✅ CKEditor에서 인식 가능한 정식 JSON 구조로 반환
            Map<String, Object> response = new HashMap<>();
            response.put("uploaded", true);
            response.put("url", imageUrl);
            return ResponseEntity.ok(response);

        } catch (IOException e) {
            e.printStackTrace();
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                    .body(Map.of("uploaded", false, "error", Map.of("message", "업로드 실패: " + e.getMessage())));
        }
    }

        // 게시글 전체 목록 조회
        @GetMapping
        public ResponseEntity<?> getAllPosts () {
            try {
                return ResponseEntity.ok(boardService.getAllPosts());
            } catch (Exception e) {
                e.printStackTrace();
                return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR)
                        .body("게시글 목록 조회 실패: " + e.getMessage());
            }
        }

        // 게시글 단건 조회
        @GetMapping("/{category}/{id}")
        public ResponseEntity<?> getPostById (@PathVariable String category, @PathVariable Long id){
            try {
                return ResponseEntity.ok(boardService.getPostById(category, id));
            } catch (Exception e) {
                e.printStackTrace();
                return ResponseEntity.status(HttpStatus.NOT_FOUND)
                        .body("게시글을 찾을 수 없습니다.");
            }
        }

        // 게시물 다운로드
        @GetMapping("/download/{filename:.+}")
        public ResponseEntity<FileSystemResource> downloadFile (@PathVariable String filename) throws IOException {
            // 파일 경로 설정
            File file = new File(uploadDir + "/" + filename);

            if (!file.exists()) {
                return ResponseEntity.notFound().build();
            }

            // 사용자에게 보여줄 원래 파일명 추출
            String originalFilename = filename.substring(filename.indexOf("_") + 1); // UUID_원본파일명 -> 원본파일명

            // 파일이 존재하면 다운로드
            if (file.exists()) {
                FileSystemResource resource = new FileSystemResource(file);
                return ResponseEntity.ok()
                        .header("Content-Disposition", "attachment; filename=\"" + file.getName() + "\"")
                        .body(resource);
            } else {
                return ResponseEntity.notFound().build();
            }
        }
    }