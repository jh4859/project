package com.example.community.community.dto;

import com.example.community.community.entity.BoardEntity;
import com.example.community.community.entity.ComImgEntity;
import lombok.Getter;
import lombok.Setter;

import java.time.LocalDateTime;
import java.util.List;
import java.util.stream.Collectors;

@Getter
@Setter
public class BoardDetailDTO {
    private Long id;
    private String title;
    private String textContent;
    private String category;
    private LocalDateTime createDate;
    private List<String> imageUrls;
    private List<CommentDTO> comments;

    public BoardDetailDTO(BoardEntity entity, List<CommentDTO> comments) {
        this.id = entity.getId();
        this.title = entity.getTitle();
        this.textContent = entity.getTextContent();
        this.category = entity.getCategory();
        this.createDate = entity.getCreatedAt();

        // populate your imageUrls from the ComImgEntity list
        this.imageUrls = entity.getImages()
                .stream()
                .map(ComImgEntity::getImgUrl)
                .collect(Collectors.toList());

        this.comments = comments;
    }
}
