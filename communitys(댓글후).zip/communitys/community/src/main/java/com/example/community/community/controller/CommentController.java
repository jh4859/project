package com.example.community.community.controller;

import com.example.community.community.dto.CommentDTO;
import com.example.community.community.service.CommentService;
import lombok.RequiredArgsConstructor;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/comments")
@RequiredArgsConstructor
public class CommentController {

    private final CommentService commentService;

    @GetMapping("/{boardId}")
    public List<CommentDTO> getComments(@PathVariable Long boardId) {
        return commentService.getCommentsByBoardId(boardId);
    }

    @PostMapping("/{boardId}")
    public CommentDTO addComment(@PathVariable Long boardId, @RequestBody CommentDTO dto) {
        return commentService.addComment(boardId, dto);
    }

    @DeleteMapping("/{commentId}")
    public void deleteComment(@PathVariable Long commentId) {
        commentService.deleteComment(commentId);
    }
}